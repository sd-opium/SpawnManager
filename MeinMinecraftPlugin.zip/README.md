# MeinPlugin

Mein erstes Minecraft-Paper-Plugin.

## Befehle

- `/setspawn` – setzt den Spawn (OPs)
- `/spawn` – teleportiert zum gesetzten Spawn

## Bauen

Voraussetzung: Java 21 und Maven.

```bash
mvn clean package
```

Die fertige JAR liegt danach in `target/`.

## Installation

Die JAR in den `plugins`-Ordner eines Paper-Servers kopieren und den Server neu starten.
